# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 13:49:08 2021

@author: Dindi Divya
"""

import numpy as np
from flask import Flask,request,jsonify,render_template
import joblib
import requests
app=Flask(__name__)
model=joblib.load('power_prediction.sav')

@app.route('/')
def home():
    return render_template("first.html")
@app.route('/predict')
def predict():
    return render_template("second.html")
@app.route('/y_predict',methods=['POST'])
def y_predict():
    ws=float(request.form['ws'])
    power=float(request.form['power'])
    x_test=[[ws,power]]
    prediction=model.predict(x_test)
    print(prediction)
    output=prediction[0]
    return render_template('second.html',prediction_text='The Energy predicted is {:.2f} KWh'.format(output))
    
    


@app.route('/windapi',methods=['POST'])
def windapi():
    city=request.form.get('place')
    apikey="fa2e55e929fcd9851a4822bf641d9f94"
    resp=requests.get("http://api.openweathermap.org/data/2.5/weather?q="+city+"&appid="+apikey+"&units=metric")
    resp=resp.json()
    temp=str(resp["main"]["temp"])+" °C"
    humid=str(resp["main"]["humidity"])+" %"
    pressure=str(resp["main"]["pressure"])+" mmHG"
    speed=str(resp["wind"]["speed"])+" m/sec"
    print(temp,humid,pressure,speed)
    return render_template("second.html",temp=temp,humid=humid,pressure=pressure,speed=speed)
    



















if __name__=='__main__':  #here main is mainfunction
    app.run(debug=True)